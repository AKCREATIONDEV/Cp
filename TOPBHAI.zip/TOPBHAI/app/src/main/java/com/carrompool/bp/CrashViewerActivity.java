package com.carrompool.bp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CrashViewerActivity extends Activity {

    private TextView tvLogContent;
    private TextView tvFilePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crash_viewer);

        // UI components ko find karna
        tvLogContent = findViewById(R.id.tvLogContent);
        tvFilePath = findViewById(R.id.tvFilePath);
        
        Button btnCrashLog = findViewById(R.id.btnCrashLog);
        Button btnNativeError = findViewById(R.id.btnNativeError);
        Button btnAppLog = findViewById(R.id.btnAppLog);

        // CrashReporter ensure karna ki initialize ho gaya hai
        CrashReporter.init(this);

        // Button clicks par functions map karna
        btnCrashLog.setOnClickListener(v -> showCrashLog());
        btnNativeError.setOnClickListener(v -> showNativeErrorLog());
        btnAppLog.setOnClickListener(v -> showAppLog());

        // Default: Open hote hi CrashLog dikhaye
        showCrashLog();
    }

    private void showCrashLog() {
        String path = CrashReporter.getCrashFilePath(this);
        String content = CrashReporter.readCrashLog(this);
        
        tvFilePath.setText("Path: " + path);
        tvLogContent.setText(content);
        Toast.makText(this, "Crash Log Loaded", Toast.LENGTH_SHORT).show();
    }

    private void showNativeErrorLog() {
        String path = CrashReporter.getNativeErrorFilePath(this);
        String content = CrashReporter.readNativeErrorLog(this);
        
        tvFilePath.setText("Path: " + path);
        tvLogContent.setText(content);
        Toast.makeText(this, "Native Error Log Loaded", Toast.LENGTH_SHORT).show();
    }

    private void showAppLog() {
        String path = CrashReporter.getLogFilePath(this);
        String content = CrashReporter.readAppLog(this);
        
        tvFilePath.setText("Path: " + path);
        tvLogContent.setText(content);
        Toast.makeText(this, "App Log Loaded", Toast.LENGTH_SHORT).show();
    }
}