package com.carrompool.bp;

import android.content.Context;
import android.os.Build;
import android.os.Process;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * CrashReporter — Java + Native crash/error ko file mein likhta hai.
 *
 * DO files create karta hai:
 *
 *   1. CrashLog.txt  — Java Exceptions + ANR + Native load errors
 *      Path priority:
 *        /storage/emulated/0/Download/CrashLog.txt   ← pehle yeh try karta hai
 *        /sdcard/Download/CrashLog.txt
 *        <AppFilesDir>/CrashLog.txt                  ← fallback (always works)
 *
 *   2. NativeLoadError.txt — specifically .so load fail hone ki info
 *      Same path priority.
 *
 * Java UncaughtExceptionHandler set karta hai — app crash hone pe automatically
 * CrashLog.txt mein exception likhta hai.
 *
 * Usage:
 *   // onCreate mein sabse pehle:
 *   CrashReporter.init(this);
 *
 *   // Custom event log karna ho toh:
 *   CrashReporter.logEvent(this, "TAG", "message");
 */
public class CrashReporter {

    private static final String TAG = "CrashReporter";

    // File names
    public static final String CRASH_FILE_NAME       = "CrashLog.txt";
    public static final String NATIVE_ERROR_FILE_NAME = "NativeLoadError.txt";
    public static final String LOG_FILE_NAME          = "AppLog.txt";

    private static Context sAppCtx;
    private static File    sCrashFile;
    private static File    sLogFile;

    private static volatile boolean sInited = false;

    // ─────────────────────────────────────────────────────────────────────────
    // INIT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Init karo — MainActivity.onCreate() mein sabse pehle call karo.
     * Thread-safe hai.
     */
    public static synchronized void init(Context ctx) {
        if (sInited) return;
        sInited = true;

        sAppCtx = ctx.getApplicationContext();
        sCrashFile = resolveFile(sAppCtx, CRASH_FILE_NAME);
        sLogFile   = resolveFile(sAppCtx, LOG_FILE_NAME);

        // Session start log
        String sessionStart = makeHeader("SESSION START — " + getTimestamp());
        appendRaw(sLogFile, sessionStart);
        appendRaw(sLogFile, buildDeviceInfo());

        // Java UncaughtExceptionHandler install karo
        installUncaughtExceptionHandler();

        Log.d(TAG, "CrashReporter initialized");
        Log.d(TAG, "  CrashLog  : " + sCrashFile.getAbsolutePath());
        Log.d(TAG, "  AppLog    : " + sLogFile.getAbsolutePath());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC WRITE METHODS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Custom event log karo (timestamp ke saath).
     *
     * Example:
     *   CrashReporter.logEvent(ctx, "NativeLoader", "libDARK_OWNER.so load hua");
     */
    public static void logEvent(Context ctx, String tag, String message) {
        ensureInit(ctx);
        String line = "[" + getTimestamp() + "] [" + tag + "] " + message;
        Log.d(TAG, line);
        appendRaw(sLogFile, line);
    }

    /**
     * AppLog.txt mein raw line append karo (NativeLoader use karta hai).
     */
    public static void appendToLog(Context ctx, String line) {
        ensureInit(ctx);
        appendRaw(sLogFile, "[" + getTimestamp() + "] " + line);
    }

    /**
     * Native .so load fail hone pe detailed error file likhta hai.
     * NativeLoader is ko call karta hai.
     */
    public static void writeNativeLoadError(Context ctx, String report) {
        ensureInit(ctx);

        File errorFile = resolveFile(ctx, NATIVE_ERROR_FILE_NAME);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(errorFile, false))) {
            bw.write(report);
            Log.e(TAG, "NativeLoadError written to: " + errorFile.getAbsolutePath());
        } catch (IOException e) {
            Log.e(TAG, "Failed to write NativeLoadError: " + e.getMessage());
        }

        // CrashLog.txt mein bhi note karo
        appendRaw(sCrashFile, "\n[" + getTimestamp() + "] NATIVE LOAD FAILED — "
                + "see " + errorFile.getAbsolutePath() + "\n");
        appendRaw(sCrashFile, report);
    }

    /**
     * @return CrashLog.txt ki full path (Display ke liye CrashViewerActivity use karta hai)
     */
    public static String getCrashFilePath(Context ctx) {
        ensureInit(ctx);
        return sCrashFile != null ? sCrashFile.getAbsolutePath() : "N/A";
    }

    /**
     * @return AppLog.txt ki full path
     */
    public static String getLogFilePath(Context ctx) {
        ensureInit(ctx);
        return sLogFile != null ? sLogFile.getAbsolutePath() : "N/A";
    }

    /**
     * @return NativeLoadError.txt ki path
     */
    public static String getNativeErrorFilePath(Context ctx) {
        return resolveFile(ctx, NATIVE_ERROR_FILE_NAME).getAbsolutePath();
    }

    /**
     * @return CrashLog.txt ka content (string mein) — CrashViewerActivity use karta hai
     */
    public static String readCrashLog(Context ctx) {
        return readFileContent(resolveFile(ctx, CRASH_FILE_NAME));
    }

    /**
     * @return AppLog.txt ka content
     */
    public static String readAppLog(Context ctx) {
        return readFileContent(resolveFile(ctx, LOG_FILE_NAME));
    }

    /**
     * @return NativeLoadError.txt ka content
     */
    public static String readNativeErrorLog(Context ctx) {
        return readFileContent(resolveFile(ctx, NATIVE_ERROR_FILE_NAME));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UNCAUGHT EXCEPTION HANDLER
    // ─────────────────────────────────────────────────────────────────────────

    private static void installUncaughtExceptionHandler() {
        final Thread.UncaughtExceptionHandler defaultHandler =
                Thread.getDefaultUncaughtExceptionHandler();

        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {

            // Stack trace string banao
            StringWriter sw = new StringWriter();
            throwable.printStackTrace(new PrintWriter(sw));
            String stackTrace = sw.toString();

            // Full crash report
            StringBuilder report = new StringBuilder();
            report.append("\n");
            report.append("========================================\n");
            report.append("  *** JAVA CRASH DETECTED ***\n");
            report.append("  Time    : ").append(getTimestamp()).append("\n");
            report.append("  Thread  : ").append(thread.getName())
                  .append(" (id=").append(thread.getId()).append(")\n");
            report.append("  PID     : ").append(Process.myPid()).append("\n");
            report.append("========================================\n\n");
            report.append("[Exception]\n");
            report.append(stackTrace).append("\n");
            report.append("[Device Info]\n");
            report.append(buildDeviceInfo());
            report.append("\n========================================\n");
            report.append("  *** END OF JAVA CRASH ***\n");
            report.append("========================================\n");

            // File mein likho (synchronous — crash ke baad bhi likha jaaye)
            appendRaw(sCrashFile, report.toString());

            Log.e(TAG, "JAVA CRASH:\n" + stackTrace);

            // Default handler ko call karo (system crash dialog ke liye)
            if (defaultHandler != null) {
                defaultHandler.uncaughtException(thread, throwable);
            }
        });

        Log.d(TAG, "UncaughtExceptionHandler installed");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FILE HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Best writable path dhundho.
     * Priority:
     *  1. /storage/emulated/0/Download/<name>  (easily accessible)
     *  2. /sdcard/Download/<name>
     *  3. <AppFilesDir>/<name>                 (always works, no permission needed)
     */
    static File resolveFile(Context ctx, String fileName) {
        String[] candidates = {
            "/storage/emulated/0/Download/" + fileName,
            "/sdcard/Download/"             + fileName,
            ctx.getFilesDir().getAbsolutePath() + "/" + fileName
        };

        for (String path : candidates) {
            File f = new File(path);
            // Parent dir exist karta hai aur writable hai?
            if (f.getParentFile() != null && f.getParentFile().exists()
                    && f.getParentFile().canWrite()) {
                return f;
            }
        }
        // Last resort — internal files dir (always writable)
        return new File(ctx.getFilesDir(), fileName);
    }

    /** File mein text append karo (thread-safe nahi — calling code ensure kare) */
    private static void appendRaw(File file, String text) {
        if (file == null) return;
        try {
            // Parent ensure karo
            if (file.getParentFile() != null && !file.getParentFile().exists()) {
                //noinspection ResultOfMethodCallIgnored
                file.getParentFile().mkdirs();
            }
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(file, true))) {
                bw.write(text);
                if (!text.endsWith("\n")) bw.newLine();
            }
        } catch (IOException e) {
            Log.e(TAG, "appendRaw failed for " + file.getAbsolutePath() + ": " + e.getMessage());
        }
    }

    private static String readFileContent(File file) {
        if (!file.exists()) return "[File not found: " + file.getAbsolutePath() + "]";
        try {
            byte[] bytes = new byte[(int) Math.min(file.length(), 512 * 1024)]; // max 512KB
            java.io.FileInputStream fis = new java.io.FileInputStream(file);
            int read = fis.read(bytes);
            fis.close();
            return read > 0 ? new String(bytes, 0, read) : "[Empty file]";
        } catch (IOException e) {
            return "[Error reading file: " + e.getMessage() + "]";
        }
    }

    private static void ensureInit(Context ctx) {
        if (!sInited && ctx != null) init(ctx);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // STRING HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    static String getTimestamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
                .format(new Date());
    }

    private static String makeHeader(String title) {
        return "\n========================================\n"
             + "  " + title + "\n"
             + "========================================\n";
    }

    private static String buildDeviceInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("  Brand  : ").append(Build.BRAND).append("\n");
        sb.append("  Model  : ").append(Build.MODEL).append("\n");
        sb.append("  Device : ").append(Build.DEVICE).append("\n");
        sb.append("  API    : ").append(Build.VERSION.SDK_INT)
          .append(" (").append(Build.VERSION.RELEASE).append(")\n");
        sb.append("  ABI    : ").append(
                Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "unknown").append("\n");
        return sb.toString();
    }
}
