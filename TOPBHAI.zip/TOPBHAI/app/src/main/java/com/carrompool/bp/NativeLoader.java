package com.carrompool.bp;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * NativeLoader — libDARK_OWNER.so ko safely load karta hai.
 *
 * Features:
 *  - System.loadLibrary() + System.load() dono try karta hai
 *  - Load fail hone pe detailed crash/error file likhta hai
 *  - Load success hone pe bhi ek log entry karta hai
 *  - CrashReporter ke saath integrate hai
 *
 * Usage (MainActivity.onCreate mein):
 *
 *   boolean loaded = NativeLoader.load(this);
 *   if (!loaded) {
 *       // .so load nahi hua — CrashViewerActivity kholo ya toast dikhao
 *   }
 */
public class NativeLoader {

    private static final String TAG      = "NativeLoader";
    private static final String LIB_NAME = "DARK_OWNER";   // libDARK_OWNER.so

    /** true agar .so successfully loaded hai is session mein */
    private static boolean sLoaded = false;

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC API
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * .so load karo. Ek baar load hone ke baad dobara load nahi karta.
     *
     * @param ctx  Context (CrashReporter ko path dene ke liye)
     * @return     true = load successful, false = load failed
     */
    public static boolean load(Context ctx) {
        if (sLoaded) return true;

        // CrashReporter initialize karo pehle — taaki error file likh sake
        CrashReporter.init(ctx);

        log(ctx, "NativeLoader: load() called — trying to load: lib" + LIB_NAME + ".so");
        log(ctx, "  Device ABI: " + getPrimaryAbi());
        log(ctx, "  Android API: " + Build.VERSION.SDK_INT);
        log(ctx, "  App files dir: " + ctx.getFilesDir().getAbsolutePath());

        // ── Step 1: System.loadLibrary() se try karo (standard Android way) ──
        try {
            System.loadLibrary(LIB_NAME);
            sLoaded = true;
            log(ctx, "NativeLoader: SUCCESS via System.loadLibrary(\"" + LIB_NAME + "\")");
            CrashReporter.logEvent(ctx, "NATIVE_LOAD_OK",
                    "lib" + LIB_NAME + ".so loaded via System.loadLibrary");
            return true;
        } catch (UnsatisfiedLinkError e1) {
            log(ctx, "NativeLoader: System.loadLibrary failed: " + e1.getMessage());
            // Step 2 try karo
        } catch (SecurityException e1) {
            log(ctx, "NativeLoader: SecurityException on loadLibrary: " + e1.getMessage());
        }

        // ── Step 2: System.load() se full path de ke try karo ───────────────
        String[] fallbackPaths = buildFallbackPaths(ctx);
        for (String path : fallbackPaths) {
            File f = new File(path);
            log(ctx, "NativeLoader: trying System.load(\"" + path + "\") — exists=" + f.exists());
            if (!f.exists()) continue;

            try {
                System.load(path);
                sLoaded = true;
                log(ctx, "NativeLoader: SUCCESS via System.load(\"" + path + "\")");
                CrashReporter.logEvent(ctx, "NATIVE_LOAD_OK",
                        "lib" + LIB_NAME + ".so loaded via System.load from: " + path);
                return true;
            } catch (UnsatisfiedLinkError e2) {
                log(ctx, "NativeLoader: System.load failed for path=" + path
                        + " | " + e2.getMessage());
            } catch (SecurityException e2) {
                log(ctx, "NativeLoader: SecurityException for path=" + path
                        + " | " + e2.getMessage());
            }
        }

        // ── LOAD FAILED — error file likhte hain ────────────────────────────
        String report = buildFailReport(ctx, fallbackPaths);
        CrashReporter.writeNativeLoadError(ctx, report);
        Log.e(TAG, "NativeLoader: FAILED to load lib" + LIB_NAME + ".so");
        return false;
    }

    /** @return true agar .so abhi tak loaded hai */
    public static boolean isLoaded() {
        return sLoaded;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIVATE HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /** Possible paths jahaan .so ho sakti hai */
    private static String[] buildFallbackPaths(Context ctx) {
        String pkg = ctx.getPackageName();
        String abi = getPrimaryAbi();
        String nativeLibDir = ctx.getApplicationInfo().nativeLibraryDir;

        return new String[]{
            // 1. App nativeLibraryDir (normal install pe yahan hoti hai)
            nativeLibDir + "/lib" + LIB_NAME + ".so",
            // 2. ABI-specific jniLibs inside APK extraction
            "/data/app/" + pkg + "-1/lib/" + abi + "/lib" + LIB_NAME + ".so",
            "/data/app/" + pkg + "-2/lib/" + abi + "/lib" + LIB_NAME + ".so",
            // 3. Android 10+ app path
            "/data/app/~~0/com.miniclip.carrom-1/lib/" + abi + "/lib" + LIB_NAME + ".so",
            // 4. App internal files (manually copied case)
            ctx.getFilesDir().getAbsolutePath() + "/lib" + LIB_NAME + ".so",
        };
    }

    /**
     * Detailed fail report banata hai — yeh CrashReporter file mein likha jaata hai
     */
    private static String buildFailReport(Context ctx, String[] triedPaths) {
        StringBuilder sb = new StringBuilder();
        sb.append("========================================\n");
        sb.append("  *** NATIVE LOAD FAILED ***\n");
        sb.append("  lib").append(LIB_NAME).append(".so load nahi hua\n");
        sb.append("========================================\n\n");

        sb.append("[Device Info]\n");
        sb.append("  Brand:       ").append(Build.BRAND).append("\n");
        sb.append("  Model:       ").append(Build.MODEL).append("\n");
        sb.append("  Android API: ").append(Build.VERSION.SDK_INT).append("\n");
        sb.append("  ABI:         ").append(getPrimaryAbi()).append("\n");
        sb.append("  All ABIs:    ").append(getAllAbis()).append("\n\n");

        sb.append("[App Info]\n");
        sb.append("  Package:     ").append(ctx.getPackageName()).append("\n");
        sb.append("  NativeLibDir:").append(ctx.getApplicationInfo().nativeLibraryDir).append("\n\n");

        sb.append("[Tried Paths]\n");
        for (String path : triedPaths) {
            File f = new File(path);
            sb.append("  ").append(path)
              .append(" [").append(f.exists() ? "EXISTS" : "NOT FOUND").append("]\n");
        }
        sb.append("\n");

        // nativeLibDir ke andar jo files hain list karo
        sb.append("[Files in nativeLibraryDir]\n");
        File nativeDir = new File(ctx.getApplicationInfo().nativeLibraryDir);
        if (nativeDir.exists()) {
            File[] files = nativeDir.listFiles();
            if (files != null && files.length > 0) {
                for (File f : files) {
                    sb.append("  ").append(f.getName())
                      .append(" (").append(f.length()).append(" bytes)\n");
                }
            } else {
                sb.append("  [EMPTY — koi .so nahi mili]\n");
            }
        } else {
            sb.append("  [DIR NOT FOUND: ").append(nativeDir.getAbsolutePath()).append("]\n");
        }
        sb.append("\n");

        sb.append("[Possible Reasons]\n");
        sb.append("  1. APK build mein ABI mismatch — ARM64 ke alawa kuch aur compile hua\n");
        sb.append("  2. NDK version mismatch — build.gradle mein ndkVersion check karo\n");
        sb.append("  3. Android.mk mein compile error tha — .so hi nahi bani\n");
        sb.append("  4. ProGuard ne kuch strip kar diya\n");
        sb.append("  5. .so bani hai par alag ABI ke liye (armeabi-v7a vs arm64-v8a)\n\n");

        sb.append("========================================\n");
        sb.append("  *** END OF NATIVE LOAD ERROR ***\n");
        sb.append("========================================\n");

        return sb.toString();
    }

    private static void log(Context ctx, String msg) {
        Log.d(TAG, msg);
        CrashReporter.appendToLog(ctx, msg);
    }

    private static String getPrimaryAbi() {
        return Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "unknown";
    }

    private static String getAllAbis() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Build.SUPPORTED_ABIS.length; i++) {
            if (i > 0) sb.append(", ");
            sb.append(Build.SUPPORTED_ABIS[i]);
        }
        return sb.toString();
    }
}
