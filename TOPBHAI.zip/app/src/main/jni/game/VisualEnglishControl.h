/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Types.h"
#include <Vector/Vectors.h>

struct VisualEnglishControl : Class {
    Field<0x3b0, Vec2d> mEnglish;

    VisualEnglishControl(ptr instance = 0) : Class(instance), mEnglish(instance) {}
};
