#pragma once

#include "Types.h"
#include "Foundation.h"
#include <Vector/Vectors.h>

struct CarromPieceEnums {
    enum Type : int {
        STRIKER = 0,
        WHITE_PUCK = 1,
        BLACK_PUCK = 2,
        QUEEN = 3,
        ANY = 99,
        ERR_TYPE = -8
    };

    enum State : int {
        DEFAULT = 1,
        IN_POCKET = 2,
        ON_BOARD = 3,
        ERR_STATE = -8
    };
};

struct CarromPiece : CarromPieceEnums, Class {
    Field<0x20, Vec2d> position; // UNVERIFIED (8BP src) — Piece position on the square board
    Field<0x30, Vec2d> velocity; // UNVERIFIED (8BP src) — Movement velocity and direction
    Field<0x40, double> radius;  // UNVERIFIED (8BP src) — Puck or Striker radius
    Field<0x60, double> mass;    // UNVERIFIED (8BP src) — Mass (Striker is heavier than pucks)
    
    Field<0xa0, Type> pieceType; // UNVERIFIED (8BP src) — Type of carrom piece
    Field<0xa4, State> state;    // UNVERIFIED (8BP src) — Current state (on board or pocketed)
    
    CarromPiece(ptr instance = 0) : Class(instance), position(instance), velocity(instance), radius(instance), pieceType(instance), state(instance) {}

    // UNVERIFIED — disabled to prevent runtime crash
    // bool isOnBoard() { auto s = this->state(); return s == State::DEFAULT || s == State::ON_BOARD; }
    bool isOnBoard() { return true; }

    operator bool() { return instance && this->isInstanceOf("CarromPiece"); }
};
