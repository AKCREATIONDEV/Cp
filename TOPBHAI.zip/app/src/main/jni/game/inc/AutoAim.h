#pragma once

#include "Prediction.h"
#include <imgui/imgui.h>

using namespace ImGui;

constexpr double maxAngle = 360.0 / (180.0 / M_PI);

double normalizeAngle(double angle) {
    double newAngle = angle;
    if (newAngle >= maxAngle) newAngle = fmod(newAngle, maxAngle);
    else if (newAngle < 0) newAngle = maxAngle - fmod(-newAngle, maxAngle);
    return newAngle;
}

bool ix = true;
namespace AutoAim {
    double lastSetAngle = 0.f;
    bool didSetAngle = false;

    // UNVERIFIED — uses mVisualStriker() (0x4B8)
    // bool shouldAutoAIM() { return !didSetAngle || lastSetAngle == sharedCarromGameManager.mVisualStriker().mVisualGuide().mAimAngle(); }
    bool shouldAutoAIM() { return false; }

    // UNVERIFIED — uses mVisualStriker() (0x4B8)
    // void setAimAngle(double angle) {
    //     lastSetAngle = angle;
    //     sharedCarromGameManager.mVisualStriker().mVisualGuide().mAimAngle(angle);
    // }
    void setAimAngle(double angle) { lastSetAngle = angle; }

    // UNVERIFIED — uses mVisualStriker() (0x4B8) — disabled to prevent runtime crash
    // void AIM(double angleStep = 0.1f) {
    //     auto startingAngle = NumberUtils::normalizeDoublePrecision(sharedCarromGameManager.mVisualStriker().mVisualGuide().mAimAngle());
    void AIM(double angleStep = 0.1f) { return; // disabled — unverified offsets
        /* dead code below — never reached
        auto startingAngle = NumberUtils::normalizeDoublePrecision(sharedCarromGameManager.mVisualStriker().mVisualGuide().mAimAngle());
        
        gPrediction->determineShotResult(true, startingAngle);
        std::vector<int> startingPottedPieces;
        for (int i = 0; i < gPrediction->guiData.piecesCount; i++) {
            Prediction::PieceState& piece = gPrediction->guiData.pieces[i];
            if (piece.originalOnTable && !piece.onTable) {
                startingPottedPieces.push_back(i);
            }
        }
        
        auto myclass = ix ? CarromPieceEnums::Type::WHITE_PUCK : CarromPieceEnums::Type::BLACK_PUCK;
        
        for (double angle = NumberUtils::normalizeDoublePrecision(normalizeAngle(startingAngle + angleStep)); angle != startingAngle; angle = NumberUtils::normalizeDoublePrecision(normalizeAngle(angle + angleStep))) {
            gPrediction->determineShotResult(true, angle);
            
            bool onlyQueenLeft = true;
            for (int i = 1; i < gPrediction->guiData.piecesCount; i++) {
                Prediction::PieceState& piece = gPrediction->guiData.pieces[i];
                if (piece.classification == myclass) {
                    if (piece.originalOnTable) onlyQueenLeft = false;
                }
            }

            std::vector<int> currentPottedPieces;
            bool isAngleGood = false;
            for (int i = 1; i < gPrediction->guiData.piecesCount; i++) {
                Prediction::PieceState& piece = gPrediction->guiData.pieces[i];
                if (piece.classification == onlyQueenLeft ? CarromPiece::Type::QUEEN : myclass) {
                    if (piece.originalOnTable && !piece.onTable) {
                        currentPottedPieces.push_back(i);
                        isAngleGood = true;
                    }
                }
            }

            if (isAngleGood && gPrediction->guiData.collision.firstHitPiece && gPrediction->guiData.collision.firstHitPiece->classification != myclass) isAngleGood = false;

            auto& striker = gPrediction->guiData.pieces[0];
            auto& queenPiece = gPrediction->guiData.pieces[8]; // Queen index in array
            if (isAngleGood && striker.originalOnTable && !striker.onTable) isAngleGood = false;
            if (isAngleGood && !onlyQueenLeft && queenPiece.originalOnTable && !queenPiece.onTable) isAngleGood = false;
            
            if (!currentPottedPieces.empty() && startingPottedPieces != currentPottedPieces && isAngleGood) {
                setAimAngle(angle);
                // LOGI("potted pieces count: %zu", currentPottedPieces.size());
                break;
            }
        }
    } */

    void Draw() {
        ImGuiIO& io = GetIO();
        float padding = 30.0f;
        SetNextWindowPos(ImVec2(io.DisplaySize.x - persistent_int["iAIM_WindowX"], persistent_int["iAIM_WindowY"]), ImGuiCond_Always, ImVec2(1.0f, 0.0f));
        SetNextWindowSize(ImVec2(210, 65), ImGuiCond_FirstUseEver);

        if (Begin("AutoAim", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings)) {
            ImVec2 windowSize = GetWindowSize();
            float availableWidth = windowSize.x - GetStyle().WindowPadding.x * 2 - GetStyle().ItemSpacing.x * 2;
            float buttonWidth = availableWidth / 3;
            float availableHeight = windowSize.y - GetStyle().WindowPadding.y * 2;
            float buttonSize = (buttonWidth < availableHeight) ? buttonWidth : availableHeight; // Make square
            
            if (Button(ix ? "W" : "B", ImVec2(buttonSize, buttonSize))) ix = !ix;
            SameLine(); if (Button("<", ImVec2(buttonSize, buttonSize))) AIM(persistent_float["fAIM_AngleStep"]);
            SameLine(); if (Button(">", ImVec2(buttonSize, buttonSize))) AIM(-persistent_float["fAIM_AngleStep"]);
        } End();
    }
};
