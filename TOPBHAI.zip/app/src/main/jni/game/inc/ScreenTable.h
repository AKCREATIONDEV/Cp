#pragma once

#include <cmath>

// Vec2d and TABLE_WIDTH/HEIGHT constants are defined in Vec2d.h and GameConstants.h
// which are included before ScreenTable.h via the include chain

// ImGui compatibility wrapper (if imgui.h is included, this matches automatically)
#ifndef IMGUI_VERSION
struct ImVec2 {
    float x, y;
    ImVec2(float _x, float _y) : x(_x), y(_y) {}
};
#else
#include <imgui.h>
#endif

// Base Game Reference Screen Resolution (1280x640 Canvas)
inline constexpr double REF_WIDTH = 1280.0;
inline constexpr double REF_HEIGHT = 640.0;

// TABLE_WIDTH/HEIGHT/HALF constants are defined in GameConstants.h

// Square Carrom Table Anchors on 1280x640 Reference Canvas
// Centered Square Play Area: Width = Height = 413.0 pixels
inline constexpr double REF_TABLE_LEFT = 433.5;
inline constexpr double REF_TABLE_RIGHT = 846.5;
inline constexpr double REF_TABLE_TOP = 113.5;
inline constexpr double REF_TABLE_BOTTOM = 526.5;

inline constexpr double REF_TABLE_CANVAS_WIDTH = REF_TABLE_RIGHT - REF_TABLE_LEFT; // 413.0

// Global Screen Dynamic Coordinates
inline double TABLE_LEFT = 0.0;
inline double TABLE_TOP = 0.0;
inline double TABLE_RIGHT = 0.0;
inline double TABLE_BOTTOM = 0.0;
inline double TABLE_SCALE = 1.0;

// Converts Physics World Coordinates (-37.0 to +37.0) -> Overlay Screen Pixels
inline ImVec2 WorldToScreen(Vec2d worldPos) {
    double positionX = worldPos.x + TABLE_HALF_WIDTH;
    double positionY = -(worldPos.y - TABLE_HALF_HEIGHT); // Y-axis inverted for 2D screen display
    
    double scrX = TABLE_LEFT + (positionX * TABLE_SCALE);
    double scrY = TABLE_TOP + (positionY * TABLE_SCALE);
    
    return ImVec2(static_cast<float>(scrX), static_cast<float>(scrY));
}

// Call this every frame before rendering prediction lines
inline void UpdateScreenTable(double screenWidth, double screenHeight) {
    // Height-based aspect scaling
    double heightScale = screenHeight / REF_HEIGHT;
    
    // Horizontal centering offset logic
    double scaledRefWidth = heightScale * REF_WIDTH;
    double offsetX = (screenWidth - scaledRefWidth) / 2.0;
    
    // Scale anchors to device resolution
    TABLE_LEFT = offsetX + (heightScale * REF_TABLE_LEFT);
    TABLE_RIGHT = offsetX + (heightScale * REF_TABLE_RIGHT);
    TABLE_TOP = heightScale * REF_TABLE_TOP;
    TABLE_BOTTOM = heightScale * REF_TABLE_BOTTOM;
    
    // Calculate world-to-screen scale factor
    TABLE_SCALE = (TABLE_RIGHT - TABLE_LEFT) / TABLE_WIDTH;
}
