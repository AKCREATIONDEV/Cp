/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Prediction.h"
