#pragma once

// Fast and normal prediction now share one Carrom implementation.  Keeping
// this forwarding header preserves the existing include structure used by
// game.h/AutoPlay without maintaining a second, stale physics engine.
#include "Prediction.h"
