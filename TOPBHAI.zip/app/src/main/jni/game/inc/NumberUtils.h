#pragma once

#include <cmath>
#include <cstdio>
#include <cstring>

#include <Vector/Vectors.h>

#include "GameConstants.h"

#define NAN std::isnan

static constexpr double DAT_04c8b998 = 0.0;
static constexpr double DAT_04c8bc98 = 4.71238898038;
static constexpr double DAT_04c8ba00 = 1.57079632679;
static constexpr double DAT_04c8b9f8 = 3.14159265359;

// Vector angle calculation routine matching native physics engine
inline void FUN_02b1bfc0(double *param_1, const Vector2D *param_2) {
    double *pdVar1;
    double dVar2;
    
    dVar2 = param_2->y;
    if (param_2->x == DAT_04c8b998) {
        pdVar1 = (double *)&DAT_04c8bc98;
        if (dVar2 < DAT_04c8b998 == (NAN(dVar2) || NAN(DAT_04c8b998))) {
            pdVar1 = (double *)&DAT_04c8ba00;
        }
        dVar2 = *pdVar1;
    }
    else {
        dVar2 = atan(dVar2 / param_2->x);
        dVar2 = round(dVar2 * 10000.0);
        dVar2 = dVar2 / 10000.0;
        if (param_2->x < DAT_04c8b998) {
            dVar2 = dVar2 + DAT_04c8b9f8;
        }
    }
    *param_1 = dVar2;
    return;
}

namespace NumberUtils {
    // Truncates and normalizes double precision values to maintain accurate physics step simulation
    inline double normalizeDoublePrecision(double value, double negativeThreshold = 0.0, double negativeExtraLen = 0.0, size_t maxLen = 7) {
        if (std::abs(value) >= 10000.0) return std::floor(value);

        char buffer[256];
        std::snprintf(buffer, sizeof(buffer), "%lf", value);
        size_t strLen = std::strlen(buffer);

        size_t allowedLen = maxLen;
        if (value < negativeThreshold) allowedLen = maxLen + negativeExtraLen;
        if (strLen > allowedLen) buffer[allowedLen] = '\0';

        double result = 0.0;
        std::sscanf(buffer, "%lf", &result);
        return result;
    }

    inline double calcAngle(const Vec2d& delta) {
        double angle;
        FUN_02b1bfc0(&angle, &delta);
        return angle;
    }

    inline double calcAngle(Vec2d source, Vec2d Destination) { 
        return calcAngle(source - Destination); 
    }
}

// Carrom Striker Drag-to-Power Conversion
// Converts drag pull back distance (0.0 to 1.0) to linear shot velocity ratio
inline double ShotPowerToPower(double shotPower) {
    // Carrom Pool uses linear to quadratic drag response for striker release
    constexpr double MAX_STRIKER_DRAG = 1.0; 
    double clampedPower = std::clamp(shotPower, 0.0, MAX_STRIKER_DRAG);
    
    // Non-linear power scaling (adjusts release velocity sensitivity)
    double powerRatio = clampedPower * (2.0 - clampedPower);
    return NumberUtils::normalizeDoublePrecision(powerRatio);
}
