#include <cmath>
#include <cstdio>
#include <cstring>
#include <array>
#include <string>

#include <Vector/Vectors.h>
#include "include/includes.h"

bool isInstanceOf(ptr obj, std::string className) { return F(char*, *(ptr*)obj + 0x10) == className; }
char* getClassName(ptr obj) { return F(char*, *(ptr*)obj + 0x10); }

// sub_1C2B0D8 - Angle/Position precision normalization function
double normalizeDoublePrecision(double value, double negativeThreshold = 0.0, double negativeExtraLen = 0.0, size_t maxLen = 7) {
    if (std::abs(value) >= 10000.0) return std::floor(value);

    char buffer[256];
    std::snprintf(buffer, sizeof(buffer), "%lf", value);
    size_t strLen = std::strlen(buffer);

    size_t allowedLen = maxLen;
    if (value < negativeThreshold) allowedLen = maxLen + negativeExtraLen;
    if (strLen > allowedLen) buffer[allowedLen] = '\0';

    double result = 0.0;
    std::sscanf(buffer, "%lf", &result);
    return result;
}

// Carrom Pool Piece Colors Mapping:
// Index 0: Striker (Light Cyan / Gold)
// Index 1: Queen (Red / Crimson)
// Index 2-10: White Pucks (Cream / White)
// Index 11-19: Black Pucks (Dark Grey / Black)
auto colors = std::to_array<ImColor>({
    ImColor(0.2f, 0.8f, 1.0f),  // 0: Striker (Bright Cyan/Blue tint)
    ImColor(1.0f, 0.15f, 0.15f),// 1: Queen (Bright Red)
    
    // 2-10: White Pieces (9 White Pucks)
    ImColor(0.95f, 0.95f, 0.9f),
    ImColor(0.95f, 0.95f, 0.9f),
    ImColor(0.95f, 0.95f, 0.9f),
    ImColor(0.95f, 0.95f, 0.9f),
    ImColor(0.95f, 0.95f, 0.9f),
    ImColor(0.95f, 0.95f, 0.9f),
    ImColor(0.95f, 0.95f, 0.9f),
    ImColor(0.95f, 0.95f, 0.9f),
    ImColor(0.95f, 0.95f, 0.9f),

    // 11-19: Black Pieces (9 Black Pucks)
    ImColor(0.15f, 0.15f, 0.15f),
    ImColor(0.15f, 0.15f, 0.15f),
    ImColor(0.15f, 0.15f, 0.15f),
    ImColor(0.15f, 0.15f, 0.15f),
    ImColor(0.15f, 0.15f, 0.15f),
    ImColor(0.15f, 0.15f, 0.15f),
    ImColor(0.15f, 0.15f, 0.15f),
    ImColor(0.15f, 0.15f, 0.15f),
    ImColor(0.15f, 0.15f, 0.15f)
});

static_assert(colors.size() == 20);
