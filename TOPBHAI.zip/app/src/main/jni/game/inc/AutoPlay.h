#pragma once

#include "Prediction.fast.h"
#include <imgui/imgui.h>
#include <algorithm>
#include "ScreenTable.h"
#include "mod/ButtonClicker.h"

using namespace ImGui;

constexpr double maxAngle = 360.0 / (180.0 / M_PI);

double normalizeAngle(double angle) {
    double newAngle = angle;
    if (newAngle >= maxAngle) newAngle = fmod(newAngle, maxAngle);
    else if (newAngle < 0) newAngle = maxAngle - fmod(-newAngle, maxAngle);
    return newAngle;
}

Candidate g_CurrentCandidate = { -1 };

ImVec2 GetPocketScreenPos(int pocketIdx) {
    // UNVERIFIED — mBoard (0x3E8), mBoardProperties (0x3B0), mPockets (0x68) not confirmed
    // Board board = sharedCarromGameManager.mBoard;
    // if (!board) return {};
    // auto boardProperties = board.mBoardProperties();
    // if (!boardProperties) return {};
    // auto& pockets = boardProperties.mPockets();
    // return WorldToScreen(pockets[pocketIdx]);
    return {};
}

bool IsShotValid() {
    auto& cand = g_CurrentCandidate;
    if (cand.idx == -1) return false;

    CarromPieceEnums::Type myclass = sharedCarromGameManager.getPlayerTargetPiece();
    uint pottedPocket = sharedCarromGameManager.getPottedPocketId();
    if (pottedPocket < 4 && cand.pocketIndex != pottedPocket) return false;

    if (!gPrediction->guiData.pieces[0].onTable) return false;
    if (!gPrediction->guiData.pieces[cand.idx].originalOnTable) return false;
    if (gPrediction->guiData.pieces[cand.idx].onTable) return false;
    if (gPrediction->guiData.pieces[cand.idx].pocketIndex != cand.pocketIndex) return false;

    auto& queenPiece = gPrediction->guiData.pieces[8];
    if (myclass == CarromPieceEnums::Type::ANY && queenPiece.originalOnTable && !queenPiece.onTable) return false;

    auto& firstHit = gPrediction->guiData.collision.firstHitPiece;
    if (firstHit) {
        if (myclass == CarromPieceEnums::Type::ANY) {
            if (firstHit->classification == CarromPieceEnums::Type::QUEEN) return false;
        } else if (firstHit->classification != myclass) return false;
    }

    return true;
}

Point2D lastFailedStrikerPos = { -1000.0, -1000.0 };

namespace AutoPlay {
    double lastSetAngle = 0.f;
    bool didSetAngle = false;
    bool bAutoPlaying = false;

    enum State {
        IDLE,
        SCANNING,
        NOMINATING,
        EXECUTING,
    } state = IDLE;
    
    double pendingShotPower = 0.f;
    double pendingShotAngle = 0.f;
    int nominationFrameCounter = 0;
    
    enum ScanMode {
        FAST,
        SLOW,
    } scan = FAST;

    bool shouldAutoPlay() { return !didSetAngle || lastSetAngle == sharedCarromGameManager.mVisualStriker().mVisualGuide().mAimAngle(); }

    void setAimAngle(double angle) {
        lastSetAngle = angle;
        sharedCarromGameManager.mVisualStriker().mVisualGuide().mAimAngle(angle);
    }

    void takeShot(double angle, double power) {
        setAimAngle(angle);
        gPrediction->determineShotResult(false, angle, power);
        sharedCarromGameManager.mVisualStriker().mPower(ShotPowerToPower(power));
        // UNVERIFIED (8BP src) — M(void, libmain + 0x2dc0c58, void*)(F(void*, sharedCarromGameManager + 0x3b0));
    }
    
    void ClearState() {
        g_CurrentCandidate.idx = -1;
        lastFailedStrikerPos = { -1000.0, -1000.0 };
    }
    
    void Shoot(double angle, double power = 0.f) {
        setAimAngle(angle);
        gPrediction->determineShotResult(false, angle, power);

        bool nominating = false;
        bool requireQueenCover = sharedCarromGameManager.isQueenCoverRequired();
        auto myclass = sharedCarromGameManager.getPlayerTargetPiece();
        if (requireQueenCover && myclass != CarromPieceEnums::Type::ANY) {
            if (g_CurrentCandidate.idx != -1 && sharedCarromGameManager.getPottedPocketId() != g_CurrentCandidate.pocketIndex) {
                nominating = true;
            }
        }

        if (nominating) {
            pendingShotPower = power;
            pendingShotAngle = angle;
            state = NOMINATING;
            nominationFrameCounter = 0;
        } else {
            takeShot(angle, power);
            ClearState();
            state = IDLE;
        }
    }
    
    void ScanSlow(double angleStep = 0.01f) {
        static double currentScanAngle = 0.0;
        static bool isScanning = false;
        static Point2D lastScanStrikerPos = { -1000.0, -1000.0 };

        if (g_CurrentCandidate.idx != -1) return;
        
        if (!isScanning || gPrediction->guiData.pieces[0].initialPosition != lastScanStrikerPos) {
            currentScanAngle = 0.0;
            isScanning = true;
            lastScanStrikerPos = gPrediction->guiData.pieces[0].initialPosition;
        }

        CarromPieceEnums::Type myclass = sharedCarromGameManager.getPlayerTargetPiece();
        uint pottedPocket = sharedCarromGameManager.getPottedPocketId();
        
        int steps = 0;
        bool foundShot = false;
        
        while (steps < 10 && currentScanAngle < maxAngle) {
            double angle = currentScanAngle;
            currentScanAngle += angleStep;
            steps++;

            std::vector<double> powers = {666.0, 466.0, 266.0, 100.0};
            for (double power : powers) {
                gPrediction->determineShotResult(true, angle, power, sharedCarromGameManager.getShotSpin());
                
                bool isPotentiallyValid = false;
                int targetIdx = -1;

                for (int i = 1; i < gPrediction->guiData.piecesCount; i++) {
                    auto& piece = gPrediction->guiData.pieces[i];
                    if (piece.originalOnTable && !piece.onTable) {
                        bool isValidTarget = false;
                        if (myclass == CarromPieceEnums::Type::ANY) {
                            if (piece.classification != CarromPieceEnums::Type::STRIKER && piece.classification != CarromPieceEnums::Type::QUEEN) isValidTarget = true;
                        } else {
                            if (piece.classification == myclass) isValidTarget = true;
                        }
                        if (pottedPocket < 4 && piece.pocketIndex != pottedPocket) isValidTarget = false;
                        if (isValidTarget) { targetIdx = i; break; }
                    }
                }

                if (targetIdx != -1) {
                    if (!gPrediction->guiData.pieces[0].onTable) continue;
                    if (!gPrediction->guiData.pieces[8].onTable && myclass != CarromPieceEnums::Type::QUEEN) continue;
                    auto firstHit = gPrediction->guiData.collision.firstHitPiece;
                    if (!firstHit) continue;
                    if (myclass == CarromPieceEnums::Type::ANY) {
                        if (firstHit->classification == CarromPieceEnums::Type::QUEEN) continue;
                    } else if (firstHit->classification != myclass) continue;

                    isPotentiallyValid = true;
                    g_CurrentCandidate.idx = targetIdx;
                    g_CurrentCandidate.angle = angle;
                    g_CurrentCandidate.power = power;
                    g_CurrentCandidate.pocketIndex = gPrediction->guiData.pieces[targetIdx].pocketIndex;
                }

                if (isPotentiallyValid) {
                    foundShot = true;
                    Shoot(angle, power);
                    break;
                }
            }
            if (foundShot) break;
        }

        if (!foundShot && currentScanAngle >= maxAngle) {
            isScanning = false;
            currentScanAngle = 0.0;
            state = IDLE;
        }
    }
    
    void ScanFast(double angleStep = 0.1f) {
        if (g_CurrentCandidate.idx != -1) return;
        if (gPrediction->guiData.pieces[0].initialPosition == lastFailedStrikerPos) return;

        double startingAngle = sharedCarromGameManager.mVisualStriker().mVisualGuide().mAimAngle();
        CarromPieceEnums::Type myclass = sharedCarromGameManager.getPlayerTargetPiece();
        uint pottedPocket = sharedCarromGameManager.getPottedPocketId();
        std::vector<Candidate> candidates;
        auto pockets = getPockets();
        auto& striker = gPrediction->guiData.pieces[0];

        for (int i = 1; i < gPrediction->guiData.piecesCount; i++) {
            auto& piece = gPrediction->guiData.pieces[i];
            if (!piece.originalOnTable) continue;

            bool isACandidate = (myclass == CarromPieceEnums::Type::ANY) ? piece.classification != CarromPieceEnums::Type::QUEEN : piece.classification == myclass;
            if (!isACandidate) continue;

            for (int pocketIdx = 0; pocketIdx < pockets.size(); pocketIdx++) {
                if (pottedPocket < 4 && pocketIdx != pottedPocket) continue;
                Point2D pocket = pockets[pocketIdx];
                Point2D toPocket = pocket - piece.initialPosition;
                double distTargetToPocket = sqrt(toPocket.square());
                if (distTargetToPocket < 0.1) continue;
                
                Point2D direction = toPocket * (1.0 / distTargetToPocket);
                Point2D ghostPiecePos = piece.initialPosition - direction * (2.0 * PIECE_RADIUS);
                Point2D shotLine = ghostPiecePos - striker.initialPosition;
                double distStrikerToTarget = sqrt(shotLine.square());
                double angle = atan2(shotLine.y, shotLine.x);
                if (angle < 0) angle += 2 * M_PI;
                
                double score = distStrikerToTarget + distTargetToPocket;
                constexpr double slidingDeceleration = 196.0;
                double power = sqrt(2.0 * slidingDeceleration * score);
                if (power > 666.0) power = 666.0;
                candidates.push_back({i, angle, score, pocketIdx, power});
            }
        }
        
        std::sort(candidates.begin(), candidates.end());
        bool foundShot = false;
        for (const auto& cand : candidates) {
            double angle = NumberUtils::normalizeDoublePrecision(normalizeAngle(cand.angle));
            gPrediction->determineShotResult(true, angle, cand.power, sharedCarromGameManager.getShotSpin(), cand);
            if (!gPrediction->firstHitIsTarget) continue;
            if (!gPrediction->guiData.pieces[0].onTable) continue;

            if (gPrediction->guiData.pieces[cand.idx].onTable) continue;
            if (gPrediction->guiData.pieces[cand.idx].pocketIndex != cand.pocketIndex) continue;

            bool isAngleGood = false;
            for (int i = 1; i < gPrediction->guiData.piecesCount; i++) {
                Prediction::PieceState& piece = gPrediction->guiData.pieces[i];
                bool match = (myclass == CarromPieceEnums::Type::ANY) ? (piece.classification != CarromPieceEnums::Type::STRIKER && piece.classification != CarromPieceEnums::Type::QUEEN) : (piece.classification == myclass);
                if (match && piece.originalOnTable && !piece.onTable) isAngleGood = true;
            }

            if (isAngleGood && gPrediction->guiData.collision.firstHitPiece) {
                 auto firstHit = gPrediction->guiData.collision.firstHitPiece;
                 if (myclass != CarromPieceEnums::Type::ANY && firstHit->classification != myclass) isAngleGood = false;
                 else if (myclass == CarromPieceEnums::Type::ANY && firstHit->classification == CarromPieceEnums::Type::QUEEN) isAngleGood = false;
            }

            if (isAngleGood && !gPrediction->guiData.pieces[0].onTable) isAngleGood = false;
            
            auto& queenPieceRef = gPrediction->guiData.pieces[8];
            if (isAngleGood && (queenPieceRef.originalOnTable && !queenPieceRef.onTable) && myclass != CarromPieceEnums::Type::QUEEN) isAngleGood = false;
            
            if (isAngleGood) {
                g_CurrentCandidate = cand;
                foundShot = true;
                Shoot(angle, cand.power);
                break;
            }
        }

        if (!foundShot) {
            lastFailedStrikerPos = striker.initialPosition;
            scan = SLOW;
        }
    }

    // UNVERIFIED — uses mVisualStriker() (0x4B8), 0x510, 0x2de6f30 — disabled to prevent crash
    // bool isAnimationActive() {
    //     auto visualStriker = sharedCarromGameManager.mVisualStriker();
    //     if (!visualStriker) return true;
    //     auto _powerBarView = F(ptr, visualStriker + 0x510);
    //     if (!_powerBarView) return true;
    //     uintptr_t activeAction = M(uintptr_t, libmain + 0x2de6f30, ptr)(_powerBarView);
    //     return (activeAction != 0);
    // }
    bool isAnimationActive() { return true; } // safe default — prevents access to unverified offsets
    
    void Update() {
        buttonClicker.Update();

        if (isAnimationActive()) return;

        if (!bAutoPlaying || !sharedCarromGameManager.mStateManager().isPlayerTurn()) {
            state = IDLE;
            return;
        }

        if (state == IDLE) {
            state = SCANNING;
            scan = FAST;
        } else if (state == SCANNING) {
            if (scan == FAST) ScanFast();
            else if (scan == SLOW) ScanSlow(0.003f);
        } else if (state == NOMINATING) {
            nominationFrameCounter++;
            if (nominationFrameCounter == 10) {
                buttonClicker.Click(GetPocketScreenPos(g_CurrentCandidate.pocketIndex));
            }
            if (nominationFrameCounter > 20 && !buttonClicker.Active) {
                takeShot(pendingShotAngle, pendingShotPower);
                ClearState();
                state = IDLE;
            }
        }
    }
};
