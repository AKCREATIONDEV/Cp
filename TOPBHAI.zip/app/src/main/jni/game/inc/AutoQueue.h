#pragma once

// StartMatch hook declaration shared by main.cpp and AutoQueue.
// Signature remains identical for Carrom Pool Matchmaking entry.
static void (*_StartMatch)(void*, int, string, int, int, int, int, int, int, uint64_t, uint32_t) = nullptr;
static void StartMatch(void* manager, int arg2, string mode, int arg4, int arg5, int arg6, int arg7, int arg8, int arg9, uint64_t arg10, uint32_t arg11) {
    if (_StartMatch) {
        _StartMatch(manager, arg2, mode, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
    }
}

// Carrom Pool Mode & Bet mapping (Delhi, Paris, London, Istanbul, etc.)
std::map<string, int64_t> modeBets = {
    {"CP2", 1000},      // 1K
    {"CP3", 5000},      // 5K
    {"CP4", 10000},     // 10K
    {"CP5", 20000},     // 20K
    {"CP6", 100000},    // 100K
    {"CP7", 250000},    // 250K
    {"CP8", 500000},    // 500K
    {"CP9", 1000000},   // 1M - Last Table
};

void StartAutoQueue() {
    LOGI("StartAutoQueue - Carrom Pool");
    if (!_StartMatch) {
        LOGI("AutoQueue: StartMatch hook is not ready");
        return;
    }
    if (!sharedMenuManager) {
        LOGI("AutoQueue: CarromMenuManager not ready");
        return;
    }

    // Carrom Board Entry Values (Fee per entry)
    static const int64_t fixedTableValues[8] = {
    1000, 5000, 10000, 20000,
    100000, 250000, 500000,
    1000000
     };

    int selected = persistent_int["iAutoQueue_FixTable"];
    if (selected < 0 || selected >= 14) selected = 0;

    const int64_t requestedBet = fixedTableValues[selected];
    string selectedMode;
    int64_t selectedBet = 0;
    for (const auto& [modeName, bet] : modeBets) {
        if (bet == requestedBet) {
            selectedMode = modeName;
            selectedBet = bet;
            break;
        }
    }

    if (selectedMode.empty()) {
        LOGI("AutoQueue: no exact game mode mapping for requested table=%lld; match not started", requestedBet);
        return;
    }

    LOGI("AutoQueue: table=%lld -> mode=%s", selectedBet, selectedMode.c_str());
    _StartMatch((void*)sharedMenuManager.instance, 0, selectedMode, 0, 0, 0, 0, 0, 0, 0x7100000001ULL, 0xffffffffU);
}

DEFINE(int64_t, popMenuState, int64_t arg1, int64_t arg2, int32_t arg3, int64_t arg4) {
    LOGI("popMenuState arg1 %p, arg2 %p, arg3 %d, arg4 %p", arg1, arg2, arg3, arg4);
    return _popMenuState(arg1, arg2, arg3, arg4);
}

void PopMenuState(int stateId) {
    LOGI("PopMenuState %d", stateId);
    // UNVERIFIED (8BP src) — auto _popMenuState = M(int64_t, libmain + 0x3051f00, int64_t, int64_t, int32_t, int64_t); // MenuManager::popMenuState:withScene:
    return;
    _popMenuState(sharedMenuManager.instance, 0, stateId, sharedMenuManager.instance);
}
