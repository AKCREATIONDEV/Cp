/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Types.h"

extern ptr libmain;

struct UserInfo : Class {
    Field<0x208, ptr> coins;
    Field<0x210, ptr> cash;
    Field<0xc0,  ptr> DisplayName;
    Field<0xd0,  ptr> loginCountryCode;

    UserInfo(ptr instance = 0) : Class(instance), coins(instance), cash(instance) {}

    operator bool() { return instance && this->isInstanceOf("UserInfo"); }
};

static UserInfo sharedUserInfo;
