/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Types.h"
#include "Foundation.h"
#include "CarromPiece.h"

extern ptr libmain;

struct BoardProperties : Class {
    FieldImpl<0x80, Vec2d*, false> mPockets;  // 19.5.1: 0x68 -> 0x80

    BoardProperties(ptr instance = 0) : Class(instance), mPockets(instance) {}

    double getPocketRadius() { return 6.0; }
    double getLength() { return 74.0; }
    double getWidth() { return 74.0; }

    operator bool() { return instance && this->isInstanceOf("CarromBoardProperties"); }
};

#include "FrictionProperties.h"

struct Board : Class {
    Field<0x3e0, BoardProperties> mBoardProperties;  // 19.5.1: 0x3c8 -> 0x3e0  // 19.5.1: +0x18
    Field<0x3f0, FrictionProperties> _frictionProperties;  // 19.5.1: 0x3d8 -> 0x3f0  // 19.5.1: +0x18
    Field<0x480, PNSArray<CarromPiece>*> mPieces;  // 19.5.1: 0x468 -> 0x480  // 19.5.1: +0x18
    Field<0x5b8, Vec4d> mBoardCollisionBounds;  // 19.5.1: 0x5a0 -> 0x5b8  // 19.5.1: +0x18

    Board(ptr instance = 0)
        : Class(instance),
          mBoardProperties(instance),
          _frictionProperties(instance),
          mPieces(instance),
          mBoardCollisionBounds(instance) {}

    operator bool() { return instance && this->isInstanceOf("Board"); }
};
