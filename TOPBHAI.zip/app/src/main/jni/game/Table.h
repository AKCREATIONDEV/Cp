#pragma once

#include "Types.h"
#include "Foundation.h"
#include "CarromPiece.h"            // defines CarromPiece

extern ptr libmain;

struct BoardProperties : Class {
    FieldImpl<0x68, Vec2d*, false> mPockets; // UNVERIFIED (8BP src)

    BoardProperties(ptr instance = 0) : Class(instance), mPockets(instance) {}

    // Carrom board standard dimensions and pocket size
    double getPocketRadius() { return 6.0; } 
    double getLength() { return 74.0; } // Square board length
    double getWidth() { return 74.0; }  // Square board width

    operator bool() { return instance && this->isInstanceOf("CarromBoardProperties"); }
};

#include "FrictionProperties.h"

struct Board : Class {
    Field<0x3b0, BoardProperties> mBoardProperties; // UNVERIFIED (8BP src)
    Field<0x3c0, FrictionProperties> _frictionProperties; // UNVERIFIED (8BP src)
    Field<0x450, PNSArray<CarromPiece>*> mPieces; // UNVERIFIED (8BP src)
    Field<0x588, Vec4d> mBoardCollisionBounds; // UNVERIFIED (8BP src) — x, y, width, height

    Board(ptr instance = 0) 
        : Class(instance), 
          mBoardProperties(instance), 
          _frictionProperties(instance), 
          mPieces(instance), 
          mBoardCollisionBounds(instance) {}

    operator bool() { return instance && this->isInstanceOf("Board"); }
};
