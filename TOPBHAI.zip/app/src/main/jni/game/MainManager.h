/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Types.h"
#include "StateManager.h"

struct MainManager : Class {
    Field<0x3b0, MainStateManager> mStateManager;

    MainManager(ptr instance = 0) : Class(instance), mStateManager(instance) {}

    operator bool() { return instance && this->isInstanceOf("MainManager"); }
};

static MainManager sharedMainManager;
