#pragma once

#include "Types.h"

// ---------------------------------------------------------
// CARROM POOL FRICTION & SURFACE PHYSICS PROPERTIES
// Adjusted for smooth wooden board & powder friction physics
// ---------------------------------------------------------

struct FrictionProperties {
    // Sliding Friction: Flat puck sliding drag on board surface
    double _coefficientOfSlidingFriction = 0.12000000000000000; 

    // Rolling Friction: Resistance to puck rotation while sliding
    double _coefficientOfRollingFriction = 0.00800000000000000; 

    // Spinning Friction: Rotational deceleration rate
    double _coefficientOfSpinningFriction = 0.01800000000000000; 

    // Time factor to reach complete rest (zero velocity)
    double _timeOfequilibriumFactor = 0.0014577259475218659; 

    // Speed reduction multiplier during slide
    double _velocityReductionSlidingFactor = 160.00000000000000; 

    // Speed reduction multiplier during roll/drag
    double _velocityReductionRollingFactor = 8.5000000000000000; 

    // Spin decay delta rate
    double _deltaSpinFactor = 9.8000000000000007; 
};
