/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Types.h"
#include "Foundation.h"
#include "CCNode.h"
#include "CarromPiece.h"
#include <cmath>
#include "inc/NumberUtils.h"

struct VisualGuide : Instance {
    Field<0x28, double> mAimAngle;
    Field<0xa0, ptr> mClassification;

    VisualGuide(ptr instance = 0) : Instance(instance), mAimAngle(instance), mClassification(instance) {}
};

struct VisualStriker : CCNode {
    Field<0x3a8, VisualGuide> mVisualGuide;
    Field<0x3b0, double> mPower;

    VisualStriker(ptr instance = 0) : CCNode(instance), mVisualGuide(instance), mPower(instance) {}

    double getShotAngle() {
        auto angle = mVisualGuide().mAimAngle();

        return angle;
    }

    double getShotPower(bool strict = false) {
        auto power = mPower();
        if (strict && power <= 0.0) return 0.0;

        if (power <= 0.0 || power > 1.0) power = 1.f;
        else power = NumberUtils::normalizeDoublePrecision(power);

        auto maxPower = 120.0;  // 19.5.1: STRIKER_PROPERTIES removed, use constant 120.0

        return (1.0 - sqrt(1.0 - power)) * maxPower;
    }

    operator bool() { return instance && this->isInstanceOf("VisualStriker"); }
};
