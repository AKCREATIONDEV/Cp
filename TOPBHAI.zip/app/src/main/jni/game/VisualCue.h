#pragma once

#include "Types.h"
#include "Foundation.h"
#include "CCNode.h"
#include "CarromPiece.h"            // defines CarromPiece
#include <cmath>
#include "inc/NumberUtils.h"

struct VisualGuide : Instance { // objCType
    Field<0x28, double> mAimAngle; // UNVERIFIED (8BP src) — VisualStriker::aimAngle()
    Field<0xa0, ptr> mClassification; // UNVERIFIED (8BP src) — isVisualGuidePointingToWrongPieceClassification

    VisualGuide(ptr instance = 0) : Instance(instance), mAimAngle(instance), mClassification(instance) {}
};

struct VisualStriker : CCNode {
    Field<0x3a8, VisualGuide> mVisualGuide; // VERIFIED (Carrom_Pool.cs)
    Field<0x3b0, double> mPower; // VERIFIED (Carrom_Pool.cs)

    VisualStriker(ptr instance = 0) : CCNode(instance), mVisualGuide(instance), mPower(instance) {}

    // UNVERIFIED — uses mAimAngle (0x28) which is unverified
    // double getShotAngle() {
    //     auto angle = mVisualGuide().mAimAngle();
    //     return NumberUtils::normalizeDoublePrecision(angle);
    // }
    double getShotAngle() { return 0.0; }

    // UNVERIFIED — uses STRIKER_PROPERTIES_MAX_POWER which is unverified
    // double getShotPower(bool strict = false) {
    //     auto power = mPower();
    //     if (strict && power <= 0.0) return 0.0;
    //     if (power <= 0.0 || power > 1.0) power = 1.f;
    //     else power = NumberUtils::normalizeDoublePrecision(power);
    //     auto maxPower = STRIKER_PROPERTIES_MAX_POWER;
    //     return (1.0 - sqrt(1.0 - power * maxPower / maxPower)) * maxPower;
    // }
    double getShotPower(bool strict = false) { return 0.0; }

    operator bool() { return instance && this->isInstanceOf("VisualStriker"); }
};
