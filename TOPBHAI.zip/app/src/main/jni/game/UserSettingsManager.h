/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Types.h"
#include "Foundation.h"

struct UserSettingsManager : Class {
    Field<0x1c, int> mPowerGaugeLocation;
    Field<0x20, int> mPowerGaugeOrientation;

    UserSettingsManager(ptr instance = 0) : Class(instance), mPowerGaugeLocation(instance), mPowerGaugeOrientation(instance) {}

    operator bool() { return instance && isInstanceOf("UserSettingsManager"); }
};

static UserSettingsManager sharedUserSettingsManager;
