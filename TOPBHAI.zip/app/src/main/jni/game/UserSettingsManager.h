#pragma once

#include "Types.h"
#include "Foundation.h"

struct UserSettingsManager : Class {
    Field<0x1c, int> mPowerGaugeLocation; // UNVERIFIED (8BP src) — 0: left, 1: right
    Field<0x20, int> mPowerGaugeOrientation; // UNVERIFIED (8BP src) — 0: horizontal, 1: vertical
 
    UserSettingsManager(ptr instance = 0) : Class(instance), mPowerGaugeLocation(instance), mPowerGaugeOrientation(instance) {}

    operator bool() { return instance && isInstanceOf("UserSettingsManager"); }
};

static UserSettingsManager sharedUserSettingsManager;
