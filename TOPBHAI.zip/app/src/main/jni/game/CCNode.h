#pragma once

#include "Types.h"

// Cocos2d Standard 2D Primitives
struct CGPoint {
    double x;
    double y;
};

struct CGSize {
    double width;
    double height;
};

struct CGRect {
    CGPoint origin;
    CGSize size;
};

// Core Base Node Structure for Cocos2d-x Engine
struct CCNode : Class {
    // Note: If contentSize or parent returns wrong data in Carrom Pool,
    // verify 0x2c8 and 0x2e0 offsets in the target libcocos2d.so version.
    Field<0x2c8, CGSize> _contentSize;
    Field<0x2e0, ptr> _parent;

    CCNode(ptr instance = 0) : Class(instance), _contentSize(instance), _parent(instance) {}

    operator bool() { return instance && this->isInstanceOf("CCNode"); }
};
