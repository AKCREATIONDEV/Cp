/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Types.h"

struct CGPoint {
    double x;
    double y;
};

struct CGSize {
    double width;
    double height;
};

struct CGRect {
    CGPoint origin;
    CGSize size;
};

struct CCNode : Class {

    Field<0x2c8, CGSize> _contentSize;
    Field<0x2e0, ptr> _parent;

    CCNode(ptr instance = 0) : Class(instance), _contentSize(instance), _parent(instance) {}

    operator bool() { return instance && this->isInstanceOf("CCNode"); }
};
