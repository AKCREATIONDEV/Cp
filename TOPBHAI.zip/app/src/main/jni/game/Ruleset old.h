#pragma once

#include <string>
#include <vector>
#include <map>
#include <typeindex>

namespace rules {
    class IRule;
    enum CarromFoulReason : int;
}

enum CarromPieceClassification : int;
class CarromPlayer;

struct Ruleset {
    int field_0x0; // 0x0
    int field_0x4; // 0x4
    std::string field_0x8; // 0x8
    int field_0x14; // 0x14
    std::map<std::type_index, rules::IRule *> field_0x18; // 0x18
    std::vector<rules::CarromFoulReason> field_0x24; // 0x24
    bool field_0x30; // 0x30
    // Padding 3 bytes
    float field_0x34; // 0x34
    int field_0x38; // 0x38
    void* field_0x3C; // 0x3C
    void* field_0x40; // 0x40
    unsigned int field_0x44; // 0x44
    void* field_0x48; // 0x48
    unsigned int field_0x4C; // 0x4C
    std::vector<CarromPieceClassification> field_0x50; // 0x50
    std::vector<CarromPieceClassification> field_0x5C; // 0x5C
    std::vector<CarromPlayer *> field_0x68; // 0x68
    int field_0x74; // 0x74
    int field_0x78; // 0x78
    int field_0x7C; // 0x7C
    int field_0x80; // 0x80
    bool field_0x84; // 0x84
    // Padding 3 bytes
    int field_0x88; // 0x88
    char field_0x8C; // 0x8C
    char field_0x8D; // 0x8D
    bool field_0x8E; // 0x8E
    bool field_0x8F; // 0x8F
    bool field_0x90; // 0x90
    // Padding 3 bytes
    unsigned int field_0x94; // 0x94
    int field_0x98; // 0x98
    char field_0x9C; // 0x9C
    // Padding 3 bytes
    unsigned int field_0xA0; // 0xA0
    bool field_0xA4; // 0xA4
    // Padding 3 bytes
    unsigned int field_0xA8; // 0xA8
};
