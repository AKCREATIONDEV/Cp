/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Types.h"

struct CCDirector : Class {

    CCDirector(ptr instance = 0) : Class(instance) {}

    operator bool() { return instance && this->isInstanceOf("CCDirector"); }
};

static CCDirector sharedDirector;
