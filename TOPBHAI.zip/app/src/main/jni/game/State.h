/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Types.h"

struct State : Class {
    Field<0x18, int32_t> mStateId;

    State(ptr instance = 0) : Class(instance), mStateId(instance) {}

    operator bool() { return instance && isInstanceOf("State"); }
};
