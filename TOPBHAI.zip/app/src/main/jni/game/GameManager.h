#pragma once

#include "StateManager.h"
#include "VisualCue.h"       // defines VisualStriker
#include "Table.h"           // defines Board
#include "VisualEnglishControl.h"

#include "inc/NumberUtils.h"
#include "CarromPiece.h"            // defines CarromPiece

// ---------------------------------------------------------
// CARROM POOL GAME MANAGER WRAPPER
// ---------------------------------------------------------

struct CarromGameManager : Class {
    Field<0x3e0, uintptr_t> _rules; // UNVERIFIED (8BP src)
    Field<0x3e8, Board> mBoard; // UNVERIFIED (8BP src)
    Field<0x4b8, VisualStriker> mVisualStriker; // UNVERIFIED (8BP src)
    Field<0x4c8, VisualEnglishControl> mVisualEnglishControl; // UNVERIFIED (8BP src)
    Field<0x508, GameStateManager> mStateManager; // UNVERIFIED (8BP src)
    Field<0x5c0, int> mGameMode; // UNVERIFIED (8BP src)

    CarromGameManager(ptr instance = 0) 
        : Class(instance), 
          _rules(instance), 
          mBoard(instance), 
          mVisualStriker(instance), 
          mVisualEnglishControl(instance), 
          mStateManager(instance), 
          mGameMode(instance) {}

    // UNVERIFIED — disabled to prevent runtime crash
    // Vec2d getShotSpin() {
    //     VisualEnglishControl visualEnglishControl = this->mVisualEnglishControl;
    //     if (!visualEnglishControl) return Vec2d(0, 0);
    //     Vec2d spin = visualEnglishControl.mEnglish;
    //     spin.x = NumberUtils::normalizeDoublePrecision(spin.x);
    //     spin.y = NumberUtils::normalizeDoublePrecision(spin.y);
    //     return spin ? spin * STRIKER_PROPERTIES_SPIN : spin;
    // }
    Vec2d getShotSpin() { return Vec2d(0, 0); }

    // UNVERIFIED — disabled to prevent runtime crash
    // CarromPieceEnums::Type getPlayerTargetPiece() {
    //     auto rules = _rules();
    //     if (!rules) return CarromPieceEnums::Type::ERR_TYPE;
    //     auto classification_vector = F(uintptr_t, rules + 0xC8);
    //     return F(CarromPieceEnums::Type, classification_vector + (mStateManager().isPlayerTurn() ? 0 : 4));
    // }
    CarromPieceEnums::Type getPlayerTargetPiece() { return CarromPieceEnums::Type::ANY; }

    // UNVERIFIED — disabled to prevent runtime crash
    // bool isQueenCoverRequired() {
    //     auto rules = _rules();
    //     if (!rules) return false;
    //     return F(bool, rules + 0x68);
    // }
    bool isQueenCoverRequired() { return false; }

    // UNVERIFIED — disabled to prevent runtime crash
    // uint getPottedPocketId() {
    //     auto rules = _rules();
    //     if (!rules) return 0;
    //     return F(uint, rules + 0x118);
    // }
    uint getPottedPocketId() { return 999; }

    operator bool() { return instance && isInstanceOf("CarromGameManager"); }
};

static CarromGameManager sharedCarromGameManager;
