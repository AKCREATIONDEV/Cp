#pragma once

#include "Types.h"

// ---------------------------------------------------------
// CARROM POOL MENU MANAGER WRAPPER
// ---------------------------------------------------------

struct MenuManager : Class {
    MenuManager(ptr instance = 0) : Class(instance) {}

    // UNVERIFIED (8BP src) — RVA 0x305114c not confirmed for Carrom Pool
    // int getMenuStateId() { 
    //     return M(int, libmain + 0x305114c, ptr)(instance); 
    // }
    int getMenuStateId() { return 0; }

    // UNVERIFIED — depends on getMenuStateId
    // bool isInQueue() { return getMenuStateId() == 12; }
    bool isInQueue() { return false; }

    operator bool() { return instance && this->isInstanceOf("MenuManager"); }
};

static MenuManager sharedMenuManager;
