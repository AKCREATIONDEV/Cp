/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/

#pragma once

#include "Types.h"

struct MenuManager : Class {
    MenuManager(ptr instance = 0) : Class(instance) {}

    int getMenuStateId() {
        return M(int, libmain + 0x01A4806C, ptr)(instance);
    }

    bool isInQueue() { return getMenuStateId() == 12; }

    operator bool() { return instance != 0; }
};

static MenuManager sharedMenuManager;
