#pragma once

#include <jni.h>
#include <vector>
#include <string>
#include "imgui.h"

// Dynamic ImGui status flag
#ifndef BIMGUI_SETUP_DEFINED
#define BIMGUI_SETUP_DEFINED
inline bool bImguiSetup = false;
#endif
#ifndef BTOUCH_OUTSIDE_DEFINED
#define BTOUCH_OUTSIDE_DEFINED
inline bool bTouchFromOutsideImGui = false;
#endif

// Custom Helper to check point collision with ImGui windows
inline bool IsPointOverAnyWindow(ImVec2 point) {
    return ImGui::IsAnyItemHovered() || ImGui::IsWindowHovered(ImGuiHoveredFlags_AnyWindow);
}

// Function Pointers for Native App Input Dispatching
typedef void (*TouchBeginFn)(JNIEnv*, jobject, jint, float, float, jboolean, jboolean);
typedef void (*TouchEndFn)(JNIEnv*, jobject, jint, float, float, jboolean, jboolean);
typedef void (*TouchMoveFn)(JNIEnv*, jobject, jintArray, jfloatArray, jfloatArray, jboolean, jboolean);

inline TouchBeginFn _nativeTouchesBegin = nullptr;
inline TouchEndFn _nativeTouchesEnd = nullptr;
inline TouchMoveFn _nativeTouchesMove = nullptr;

// Generic Input Handler Functions
inline void nativeTouchesBegin(JNIEnv* env, jobject obj, jint i, float x, float y, jboolean isObscured, jboolean isPartiallyObscured) {
    if (!bImguiSetup) {
        if (_nativeTouchesBegin) _nativeTouchesBegin(env, obj, i, x, y, isObscured, isPartiallyObscured);
        return;
    }

    if (i == 0) {
        ImGuiIO& io = ImGui::GetIO();
        io.MouseDown[i] = true;
        io.MousePos = ImVec2(x, y);

        bTouchFromOutsideImGui = !IsPointOverAnyWindow(ImVec2(x, y));
    }

    if (bTouchFromOutsideImGui && _nativeTouchesBegin) {
        _nativeTouchesBegin(env, obj, i, x, y, isObscured, isPartiallyObscured);
    }
}

inline void nativeTouchesEnd(JNIEnv* env, jobject obj, jint i, float x, float y, jboolean isObscured, jboolean isPartiallyObscured) {
    if (!bImguiSetup) {
        if (_nativeTouchesEnd) _nativeTouchesEnd(env, obj, i, x, y, isObscured, isPartiallyObscured);
        return;
    }
    
    if (i == 0) {
        ImGuiIO& io = ImGui::GetIO();
        io.MouseDown[i] = false;
        
        if (bTouchFromOutsideImGui) {
            bTouchFromOutsideImGui = false;
        } else {
            return;
        }
    }
    
    if (_nativeTouchesEnd) {
        _nativeTouchesEnd(env, obj, i, x, y, isObscured, isPartiallyObscured);
    }
}

inline void nativeTouchesMove(JNIEnv* env, jobject obj, jintArray ids, jfloatArray xs, jfloatArray ys, jboolean isObscured, jboolean isPartiallyObscured) {
    if (!bImguiSetup) {
        if (_nativeTouchesMove) _nativeTouchesMove(env, obj, ids, xs, ys, isObscured, isPartiallyObscured);
        return;
    }

    jsize length = env->GetArrayLength(ids);
    if (length <= 0) {
        if (_nativeTouchesMove) _nativeTouchesMove(env, obj, ids, xs, ys, isObscured, isPartiallyObscured);
        return;
    }

    jint* id_elements = env->GetIntArrayElements(ids, NULL);
    jfloat* x_elements = env->GetFloatArrayElements(xs, NULL);
    jfloat* y_elements = env->GetFloatArrayElements(ys, NULL);
    
    int i = id_elements[0];
    float x = x_elements[0], y = y_elements[0];

    env->ReleaseIntArrayElements(ids, id_elements, JNI_ABORT);
    env->ReleaseFloatArrayElements(xs, x_elements, JNI_ABORT);
    env->ReleaseFloatArrayElements(ys, y_elements, JNI_ABORT);

    if (i == 0) {
        ImGuiIO& io = ImGui::GetIO();
        io.MousePos = ImVec2(x, y);
    }
    
    if (bTouchFromOutsideImGui && _nativeTouchesMove) {
        _nativeTouchesMove(env, obj, ids, xs, ys, isObscured, isPartiallyObscured);
    }
}

// Manual Touch Event Generators
inline void NativeTouchesBegin(JNIEnv* env, int idx, float x, float y) {
    nativeTouchesBegin(env, nullptr, idx, x, y, false, false);
}

inline void NativeTouchesEnd(JNIEnv* env, int idx, float x, float y) {
    nativeTouchesEnd(env, nullptr, idx, x, y, false, false);
}

inline void NativeTouchesMove(JNIEnv* env, int idx, float x, float y) {
    jintArray ids = env->NewIntArray(1);
    env->SetIntArrayRegion(ids, 0, 1, &idx);
    jfloatArray xs = env->NewFloatArray(1);
    env->SetFloatArrayRegion(xs, 0, 1, &x);
    jfloatArray ys = env->NewFloatArray(1);
    env->SetFloatArrayRegion(ys, 0, 1, &y);
    
    nativeTouchesMove(env, nullptr, ids, xs, ys, false, false);
    
    env->DeleteLocalRef(ids);
    env->DeleteLocalRef(xs);
    env->DeleteLocalRef(ys);
}
