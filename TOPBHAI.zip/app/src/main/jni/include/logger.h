#pragma once

#include <android/log.h>

#ifndef LOG_TAG
#define LOG_TAG "AppNativeLogger"
#endif

// Toggle debug mode dynamically or via compiler flags (-DNDEBUG)
#ifdef NDEBUG
    // Release mode: Strip out verbose logging overhead
    #define LOGI(...) ((void)0)
    #define LOGD(...) ((void)0)
    #define LOGW(...) ((void)0)
    #define LOGE(...) ((void)0)
#else
    // Debug mode: Output logs to logcat
    #define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
    #define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
    #define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
    #define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#endif

// Conditional execution wrappers with inline string logging
#define IFL(cond) if ([&](){ bool _res = (cond); if (_res) LOGI("%s", #cond); return _res; }())
#define IFLN(cond) if ([&](){ bool _res = (cond); if (!_res) LOGI("!(%s)", #cond); return _res; }())
