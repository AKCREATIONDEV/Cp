#pragma once

#include <android/input.h>
#include <android/native_window.h>
#include <android_native_app_glue/android_native_app_glue.h>
#include <imgui.h>
#include <imgui_impl_android.h>

// Global window layout tracking
struct DisplayLayout {
    int width = 0;
    int height = 0;
    float offsetX = 0.0f; // Cutout / notch offset
    float offsetY = 0.0f;
};

inline DisplayLayout g_DisplayLayout;

// Calculate touch coordinates considering display insets
inline ImVec2 GetAdjustedTouchCoordinates(AInputEvent* event, size_t pointerIndex) {
    float rawX = AMotionEvent_getRawX(event, pointerIndex);
    float rawY = AMotionEvent_getRawY(event, pointerIndex);

    // Apply layout offset (e.g., notch offset in landscape orientation)
    float adjustedX = rawX - g_DisplayLayout.offsetX;
    float adjustedY = rawY - g_DisplayLayout.offsetY;

    return ImVec2(adjustedX, adjustedY);
}

// Standard NDK Motion Event Dispatcher for ImGui
inline int32_t ProcessStandardInputEvent(struct android_app* app, AInputEvent* event) {
    if (!event) return 0;

    int32_t type = AInputEvent_getType(event);
    if (type == AINPUT_EVENT_TYPE_MOTION) {
        int32_t action = AMotionEvent_getAction(event);
        int32_t actionMasked = action & AMOTION_EVENT_ACTION_MASK;
        size_t pointerIndex = (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;

        ImGuiIO& io = ImGui::GetIO();
        ImVec2 touchPos = GetAdjustedTouchCoordinates(event, pointerIndex);
        io.MousePos = touchPos;

        if (actionMasked == AMOTION_EVENT_ACTION_DOWN || actionMasked == AMOTION_EVENT_ACTION_POINTER_DOWN) {
            io.MouseDown[0] = true;
        } else if (actionMasked == AMOTION_EVENT_ACTION_UP || actionMasked == AMOTION_EVENT_ACTION_POINTER_UP) {
            io.MouseDown[0] = false;
        }

        // Return 1 to consume event if ImGui hovered/active, 0 to allow app background handling
        return io.WantCaptureMouse ? 1 : 0;
    }

    return 0;
}

// Standard Native Activity Event Loop Handler
inline void OnAppCmd(struct android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW:
            if (app->window != nullptr) {
                g_DisplayLayout.width = ANativeWindow_getWidth(app->window);
                g_DisplayLayout.height = ANativeWindow_getHeight(app->window);
                ImGui_ImplAndroid_Init(app->window);
            }
            break;
        case APP_CMD_TERM_WINDOW:
            ImGui_ImplAndroid_Shutdown();
            break;
    }
}
