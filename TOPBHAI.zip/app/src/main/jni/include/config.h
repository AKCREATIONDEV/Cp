/*
•Owner: @GVM_TRUST ✅ 
•Carrom Hack and Src Buy Paid : @GVM_TRUST ✅ 
•SrcCahanel: @GE_SRC     , @GALVNIC_BYPASS ✅ 
•FixedSrc Only For Free User Buy Paid Src To Owner Message To owner ✅ 👍 
*/
#pragma once

struct FeatureConfig {
    // AIM
    bool aimEnabled        = false;
    bool aimAutoAngle      = false;
    bool aimAutoPower      = false;
    bool aimIgnorePocketed = true;
    bool aimDrawFov        = true;
    int  aimTargetPriority = 0;
    float aimFov           = 120.0f;
    float aimMinPower      = 20.0f;
    float aimMaxPower      = 100.0f;

    // ESP
    bool espEnabled           = false;
    bool espLine              = false;
    bool espPredictionLine    = true;
    bool espTargetIndicator   = true;
    bool espGhostPiece        = true;
    bool espQueenFocus        = false;
    int  espGuidelineStyle    = 0;
    float espGuidelineThickness = 2.5f;
    float espTrajectoryAlpha    = 0.8f;

    // AUTO PLAY
    bool autoPlayEnabled      = false;
    bool autoPlayHumanized    = true;
    float autoPlayDelayMs     = 350.0f;
    int  autoPlayScanMode     = 0;   // 0=FAST 1=SLOW

    // QUEUE
    bool autoQueueEnabled     = false;
    int  autoQueueGameMode    = 0;   // 0=Carrom 1=DiscPool 2=Freestyle
    int  autoQueueCoinIndex   = 0;

    // TABLE
    bool cleanTable           = false;

    // MISC
    bool touchBlocker         = false;
};

inline FeatureConfig g_cfg;
